package com.example.testuiscreens;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class ExplanationActivity extends AppCompatActivity implements View.OnClickListener {
    Button continueBtn;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.explanation_view);
        continueBtn= findViewById(R.id.continueBtn);

        continueBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v==continueBtn){
            Intent i= new Intent(ExplanationActivity.this,EmailVerificationActivity.class);
            startActivity(i);
        }
    }
}
